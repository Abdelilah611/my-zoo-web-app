<?php declare(strict_types=1);

namespace Amp\Dns;

class DnsTimeoutException extends DnsException
{
}
