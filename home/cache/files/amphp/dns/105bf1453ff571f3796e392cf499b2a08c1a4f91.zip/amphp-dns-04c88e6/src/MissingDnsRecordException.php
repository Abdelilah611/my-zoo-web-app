<?php declare(strict_types=1);

namespace Amp\Dns;

class MissingDnsRecordException extends DnsException
{
}
