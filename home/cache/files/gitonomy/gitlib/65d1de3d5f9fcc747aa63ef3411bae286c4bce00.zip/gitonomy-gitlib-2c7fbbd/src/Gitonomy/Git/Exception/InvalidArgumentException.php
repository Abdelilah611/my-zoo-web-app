<?php

namespace Gitonomy\Git\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements GitExceptionInterface
{
}
