<?php

namespace Gitonomy\Git\Exception;

class UnexpectedValueException extends \UnexpectedValueException implements GitExceptionInterface
{
}
